Versions of Python since 2.5 include ctypes, easily letting you interface directly with a Windows .dll or a Linux .so.  Two .py files are included that let you do this: DevIL-Windows.py and DevIL-Linux.py.

For more information on ctypes, visit http://starship.python.net/crew/theller/ctypes/ .







Here is the text for the old version of the DevIL Python wrapper (still included at the moment):

The test program require Pygame and PyOpenGL to work but 
you don't need them to use the library. You can find the 
needed package at:

Pygame   - http://www.pygame.org
PyOpenGL - http://pyopengl.sourceforge.net

